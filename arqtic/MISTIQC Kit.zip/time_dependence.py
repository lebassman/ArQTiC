import numpy as np

def external_func(t):
	freq=0.0048
	return np.sin(freq*t)